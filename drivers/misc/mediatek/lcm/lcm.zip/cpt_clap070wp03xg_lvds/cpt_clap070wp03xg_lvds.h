#ifndef __CPT_ALAP070WP03xg_LVDS_H__
#define __CPT_ALAP070WP03xg_LVDS_H__

void lcm_get_gpio(void);

#endif
